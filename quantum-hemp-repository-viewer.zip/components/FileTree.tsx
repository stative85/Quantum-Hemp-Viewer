
import React, { useState } from 'react';
import type { FileSystemNode } from '../types';
import { ChevronRightIcon, FolderIcon, FileIcon, PythonIcon, MarkdownIcon, TableIcon, ImageIcon } from './Icons';

interface FileTreeProps {
  nodes: FileSystemNode[];
  onSelectFile: (path: string) => void;
  selectedPath: string | null;
}

const getFileIcon = (fileName: string) => {
  if (fileName.endsWith('.py')) return <PythonIcon className="w-4 h-4 mr-2" />;
  if (fileName.endsWith('.md')) return <MarkdownIcon className="w-4 h-4 mr-2" />;
  if (fileName.endsWith('.csv')) return <TableIcon className="w-4 h-4 mr-2" />;
  if (fileName.endsWith('.png')) return <ImageIcon className="w-4 h-4 mr-2" />;
  return <FileIcon className="w-4 h-4 mr-2" />;
};


const TreeNode: React.FC<{ 
    node: FileSystemNode; 
    onSelectFile: (path: string) => void; 
    selectedPath: string | null;
    path: string;
}> = ({ node, onSelectFile, selectedPath, path }) => {
  
  if (node.type === 'directory') {
    const [isOpen, setIsOpen] = useState(true);
    return (
      <div>
        <div 
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center px-2 py-1.5 text-sm rounded-md cursor-pointer hover:bg-slate-700/50"
        >
          <ChevronRightIcon className={`w-4 h-4 mr-1 transition-transform ${isOpen ? 'rotate-90' : ''}`} />
          <FolderIcon className="w-4 h-4 mr-2 text-sky-400" />
          <span className="font-medium text-slate-300">{node.name}</span>
        </div>
        {isOpen && (
          <div className="pl-4 border-l border-slate-700 ml-2.5">
            {node.children.map(child => (
              <TreeNode 
                key={child.name} 
                node={child} 
                onSelectFile={onSelectFile} 
                selectedPath={selectedPath}
                path={`${path}/${child.name}`}
              />
            ))}
          </div>
        )}
      </div>
    );
  }

  const isSelected = selectedPath === path;

  return (
    <div 
      onClick={() => onSelectFile(path)}
      className={`flex items-center px-2 py-1.5 text-sm rounded-md cursor-pointer group ${isSelected ? 'bg-sky-500/20 text-sky-300' : 'hover:bg-slate-700/50 text-slate-400 hover:text-slate-300'}`}
    >
      <div className="w-4 mr-1"></div> {/* Spacer */}
      {getFileIcon(node.name)}
      <span>{node.name}</span>
    </div>
  );
};


const FileTree: React.FC<FileTreeProps> = ({ nodes, onSelectFile, selectedPath }) => {
  return (
    <div className="space-y-1">
      {nodes.map(node => (
        <TreeNode key={node.name} node={node} onSelectFile={onSelectFile} selectedPath={selectedPath} path={node.name} />
      ))}
    </div>
  );
};

export default FileTree;
