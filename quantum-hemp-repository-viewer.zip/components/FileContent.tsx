
import React, { useState, useEffect } from 'react';
import type { FileNode } from '../types';
import { ClipboardIcon, CheckIcon, FileCodeIcon } from './Icons';

interface FileContentProps {
  file: FileNode | null;
  path: string | null;
}

const FileContent: React.FC<FileContentProps> = ({ file, path }) => {
  const [isCopied, setIsCopied] = useState(false);

  useEffect(() => {
    setIsCopied(false);
  }, [file]);

  const handleCopy = () => {
    if (file?.content) {
      navigator.clipboard.writeText(file.content);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    }
  };

  if (!file || !path) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center text-slate-500">
        <FileCodeIcon className="w-16 h-16 mb-4" />
        <h2 className="text-xl font-semibold">Select a file to view its content</h2>
        <p>Choose a file from the project explorer on the left.</p>
      </div>
    );
  }

  const isMarkdown = path.endsWith('.md');

  return (
    <div className="flex flex-col flex-1 h-full min-h-0 bg-slate-800/50">
      <div className="flex items-center justify-between p-3 border-b border-slate-700">
        <span className="font-mono text-sm text-slate-400">{path}</span>
        <button
          onClick={handleCopy}
          className="flex items-center px-2 py-1 text-xs text-slate-400 bg-slate-700 hover:bg-slate-600 rounded-md transition-colors"
        >
          {isCopied ? (
            <>
              <CheckIcon className="w-3 h-3 mr-1 text-green-400" />
              Copied!
            </>
          ) : (
            <>
              <ClipboardIcon className="w-3 h-3 mr-1" />
              Copy
            </>
          )}
        </button>
      </div>
      <div className="flex-1 p-6 overflow-auto">
        <pre className={`text-sm leading-relaxed whitespace-pre-wrap break-words ${isMarkdown ? 'prose-invert' : 'font-mono'}`}>
          <code>{file.content}</code>
        </pre>
      </div>
    </div>
  );
};

export default FileContent;
